
     
<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-lg-12 margin-tb">
            <div class="pull-left">
                <h2>Laravel 8 CRUD with Image Upload Example from scratch - ItSolutionStuff.com</h2>
            </div>
            <div class="pull-right">
                <a class="btn btn-success" href="<?php echo e(route('data.create')); ?>"> Create New Data</a>
            </div>
        </div>
    </div>
    
    <?php if($message = Session::get('success')): ?>
        <div class="alert alert-success">
            <p><?php echo e($message); ?></p>
        </div>
    <?php endif; ?>
     
    <table class="table table-bordered">
        <tr>
            <th>No</th>
            <th>Image</th>
            <th>Name</th>
            <th>Position</th>
            <th>Status</th>
            <th width="280px">Action</th>
        </tr>
        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $datas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e(++$i); ?></td>
            <td><img src="/image/<?php echo e($datas->image); ?>" width="100px"></td>
            <td><?php echo e($datas->name); ?></td>
            <td><?php echo e($datas->position); ?></td>
            <td><?php echo e($datas->status); ?></td>
            <!-- <td><?php echo e($datas->detail); ?></td> -->
            <td>
                <form action="<?php echo e(route('data.destroy',$datas->id)); ?>" method="POST">
     
                    <a class="btn btn-info" href="<?php echo e(route('data.show',$datas->id)); ?>">Show</a>
      
                    <a class="btn btn-primary" href="<?php echo e(route('data.edit',$datas->id)); ?>">Edit</a>
     
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
        
                    <button type="submit" class="btn btn-danger">Delete</button>
                </form>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
    
    <?php echo $data->links(); ?>

        
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Laravel\Task\resources\views/Data/index.blade.php ENDPATH**/ ?>